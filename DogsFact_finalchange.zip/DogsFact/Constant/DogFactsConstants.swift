//
//  DogFactsConstants.swift
//  DogsFact
//
//  Created by Jyoti Kumari on 04/01/24.
//

import Foundation

struct NAConstants {
    static let title: String = "Dog Facts"
    static let factsLoadFail: String = "Facts Loading Failed"
}

//
//  DogFactsAPI.swift
//  DogsFact
//
//  Created by Jyoti Kumari on 02/01/24.
//

struct DogFactsAPI {
    let environment: Environment
    
    init(environment: Environment) {
        self.environment = environment
    }
}

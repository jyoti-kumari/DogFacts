//
//  DogFactData.swift
//  DogsFact
//
//  Created by Jyoti Kumari on 02/01/24.
//

struct DogFactData {
    let factMessage: String
}
